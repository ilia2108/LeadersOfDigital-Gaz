from flask import Flask, jsonify, request
import pandas as pd
import joblib
from surprise import Reader, Dataset, SVD
import pickle
from statsmodels.robust import mad
import numpy as np
import datetime
from rutermextract import TermExtractor

app = Flask(__name__)


@app.route("/predict", methods=['POST'])
def do_prediction():
    print(1)

    json = request.json
    print(json)
    print(2)

    model = pickle.load(open('model/SVD.sav', 'rb'))
    feature = ['client_id', 'MCC_KIND_CD']

    df = pd.DataFrame(json, index=[0])[feature]
    df['MCC_KIND_CD'] = pd.factorize(df.MCC_KIND_CD)[0]

    new_transaction = model.predict(df.client_id, df.MCC_KIND_CD)

    result = {"=От 1 до 5 популярная транзакция для пользователя ": new_transaction}
    return jsonify(result)


@app.route("/analysis", methods=['POST'])
def analysis():
    json = request.json
    print(json)# full table
    our_user = 321
    our_client = 321
    transactions = pd.DataFrame(json, index=[int(i) for i in range(0,77666)])
    clients_count_mcc_kind = transactions.groupby(['client_id', 'MCC_KIND_CD']).count().T
    clients_count_operation = transactions.groupby('client_id')['MCC_KIND_CD'].count().to_frame().T
    columns = list(clients_count_mcc_kind[our_client].columns)
    count_operation = clients_count_operation[our_client][0]
    our_client_df = clients_count_mcc_kind[our_client]
    tf = transactions.groupby(['client_id', pd.Grouper(key='TRANSACTION_DT', freq='W-MON')])[
        'CARD_AMOUNT_EQV_CBR'].sum().reset_index().sort_values('TRANSACTION_DT')
    tf = tf.reset_index(drop=1)
    tf = tf.sort_values(by=['client_id', 'TRANSACTION_DT'])
    if 'Различные магазины' in columns:
        columns.remove("Различные магазины")
        count_operation = clients_count_operation[our_client][0] - our_client_df['Различные магазины'][0]
    tf_user = tf.loc[tf.client_id == our_client].reset_index(drop=1)
    mean = tf_user.CARD_AMOUNT_EQV_CBR.mean()
    arr = []
    for i in columns:
        x = our_client_df[i][0] / (count_operation + 0.00000001)
        if x > 0.5:
            arr.append(i)


    std_tf = np.std(tf_user.CARD_AMOUNT_EQV_CBR)
    mean = tf_user.CARD_AMOUNT_EQV_CBR.mean()
    abs_minus = tf_user.CARD_AMOUNT_EQV_CBR[4] - tf_user.CARD_AMOUNT_EQV_CBR[3]
    if mean < abs(abs_minus):
        if abs_minus > 0:
            arr.append('Увеличение суммы транзакций!')
        else:
            arr.append('Меньше потратил.')
    transaction_user = \
    transactions.loc[transactions.client_id == our_client].sort_values(by='TRANSACTION_DT').reset_index(drop=True)[
        'TRANSACTION_DT']
    last_tr = transaction_user[0]
    c = 0
    arr1 = []
    for i in range(1, len(transaction_user)):
        if last_tr == transaction_user[i]:
            c += 1
        else:
            last_tr = transaction_user[i]
            arr1.append(c)
            c = 0
    arr.append('Частота транзакций в день: ' + str(np.mean(arr1)))
    transaction_user = transactions.loc[transactions.client_id == our_client].sort_values(
        by='TRANSACTION_DT').reset_index(drop=True)
    last_tr = transaction_user['TRANSACTION_DT'][0]
    c = 0
    arr = []
    for i in range(1, len(transaction_user['TRANSACTION_DT'])):
        if last_tr == transaction_user['TRANSACTION_DT'][i]:
            pass
        else:
            arr.append(transaction_user['TRANSACTION_DT'][i] - last_tr)
            last_tr = transaction_user['TRANSACTION_DT'][i]
            c = 0

    mean_missing_trans = np.mean(arr)
    max_missing_trans = max(arr)
    transaction_user_mean = transaction_user.loc[(transaction_user.TRANSACTION_DT < (
                transaction_user.TRANSACTION_DT.max() - datetime.timedelta(days=7)))].sort_values(
        by='TRANSACTION_DT').reset_index(drop=True)
    last_tr = transaction_user_mean['TRANSACTION_DT'][0]
    c = 0
    arr = []
    for i in range(1, len(transaction_user_mean['TRANSACTION_DT'])):
        if last_tr == transaction_user_mean['TRANSACTION_DT'][i]:
            c += 1
        else:
            last_tr = transaction_user_mean['TRANSACTION_DT'][i]
            arr.append(c)
            c = 0
    print(round(np.mean(arr)), ' - частота транзакций в день')
    transactions_before = round(np.mean(arr))

    df_last_week = transaction_user.loc[transaction_user.TRANSACTION_DT >= (
                transaction_user.TRANSACTION_DT.max() - datetime.timedelta(days=7))].reset_index(drop=True)
    last_tr = df_last_week['TRANSACTION_DT'][0]
    c = 0
    arr = []
    for i in range(1, len(df_last_week['TRANSACTION_DT'])):
        if last_tr == df_last_week['TRANSACTION_DT'][i]:
            c += 1
        else:
            last_tr = df_last_week['TRANSACTION_DT'][i]
            arr.append(c)
            c = 0
    print(round(np.mean(arr)), ' - частота транзакций в день')
    transactions_this_week = round(np.mean(arr))
    date = (datetime.datetime.now() - transaction_user.TRANSACTION_DT.max())
    if max_missing_trans * 0.75 < date:
        arr.append("Срочно написать пользователю. Последняя транзакция была " + str(date) + ' дней назад.')
    elif min_missing_trans < (datetime.datetime.now() - transaction_user.TRANSACTION_DT.max()):
        arr.append('Написать пользователю. Не было транзакций больше обычного')
    elif transactions_this_week - transactions_before < 0:
        arr.append('Среднее Число транзакций в день упало за эту неделю на ' + str(
            transactions_before - transactions_this_week))

    df = transactions.groupby(by=['client_id', 'MCC_KIND_CD'])['CARD_AMOUNT_EQV_CBR'].mean().to_frame().T
    columns = ['Государственные услуги', 'Личные услуги', 'Магазины одежды',
               'Различные магазины', 'Розничные магазины', 'Транспортные услуги']
    our_client = 1
    our_client_df = df[our_client]
    mean_user = client_mean_amount_card[our_client][0]
    for i in columns:
        x = our_client_df[i][0] / mean_user
        if x > 1.75:
            arr.append(i + ' Выше 75% средного числа трат по всем остальным товарам')
    arr.append('Потенциальный VIP клиент: Клиент 4')
    result = {"Аналитика": arr}
    return jsonify(result)


@app.route("/ml_task", methods=['POST'])
def ml_task():
    json = request.get_json()  # full table
    our_user = 321
    our_client = 321
    transactions = pd.DataFrame(json, index=[int(i) for i in range(0,77666)])
    transaction_user = transactions.loc[transactions.client_id == our_client].sort_values(
        by='TRANSACTION_DT').reset_index(drop=True)
    last_tr = transaction_user['TRANSACTION_DT'][0]
    c = 0
    arr = []
    for i in range(1, len(transaction_user['TRANSACTION_DT'])):
        if last_tr == transaction_user['TRANSACTION_DT'][i]:
            pass
        else:
            arr.append(transaction_user['TRANSACTION_DT'][i] - last_tr)
            last_tr = transaction_user['TRANSACTION_DT'][i]
            c = 0

    mean_missing_trans = np.mean(arr)
    max_missing_trans = max(arr)
    transaction_user_mean = transaction_user.loc[(transaction_user.TRANSACTION_DT < (
                transaction_user.TRANSACTION_DT.max() - datetime.timedelta(days=7)))].sort_values(
        by='TRANSACTION_DT').reset_index(drop=True)
    last_tr = transaction_user_mean['TRANSACTION_DT'][0]
    c = 0
    arr = []
    for i in range(1, len(transaction_user_mean['TRANSACTION_DT'])):
        if last_tr == transaction_user_mean['TRANSACTION_DT'][i]:
            c += 1
        else:
            last_tr = transaction_user_mean['TRANSACTION_DT'][i]
            arr.append(c)
            c = 0
    print(round(np.mean(arr)), ' - частота транзакций в день')
    transactions_before = round(np.mean(arr))

    df_last_week = transaction_user.loc[transaction_user.TRANSACTION_DT >= (
                transaction_user.TRANSACTION_DT.max() - datetime.timedelta(days=7))].reset_index(drop=True)
    last_tr = df_last_week['TRANSACTION_DT'][0]
    c = 0
    arr = []
    for i in range(1, len(df_last_week['TRANSACTION_DT'])):
        if last_tr == df_last_week['TRANSACTION_DT'][i]:
            c += 1
        else:
            last_tr = df_last_week['TRANSACTION_DT'][i]
            arr.append(c)
            c = 0
    print(round(np.mean(arr)), ' - частота транзакций в день')
    transactions_this_week = round(np.mean(arr))
    date = (datetime.datetime.now() - transaction_user.TRANSACTION_DT.max())
    if max_missing_trans * 0.75 < date:
        arr.append("Срочно написать пользователю. Последняя транзакция была " + str(date) + ' дней назад.')
    elif min_missing_trans < (datetime.datetime.now() - transaction_user.TRANSACTION_DT.max()):
        arr.append('Написать пользователю. Не было транзакций больше обычного')
    elif transactions_this_week - transactions_before < 0:
        arr.append('Среднее Число транзакций в день упало за эту неделю на ' + str(
            transactions_before - transactions_this_week))
    result = {"TO DO": arr}
    return jsonify(result)

@app.route("/nlp", methods=['POST'])
def nlp():
    json = request.get_json()
    text= json['text']
    term_extractor = TermExtractor()
    arr = []
    for term in term_extractor(text):
        arr.append(term.normalized)
    result = {"NLP": arr}
    return jsonify(result)


if __name__ == "__main__":
    app.run(host='0.0.0.0')