import React from "react";
import { BrowserRouter, Switch, Route } from "react-router-dom";
import {ChatBot} from 'react-simple-chatbot';



import Navbar from "./components/Navbar";

import Home from "./pages/Home";
import About from "./pages/About";
import Dashboard from "./pages/Dashboard";

function App() {const steps = [
  {
    id: '0',
    message: 'Welcome to react chatbot!',
    trigger: '1',
  },
  {
    id: '1',
    message: 'Bye!',
    end: true,
  },
];
  return (
    <BrowserRouter>
      <Navbar />
      <div className="container mt-2" >
        <Switch>
          <Route exact path="/">
            <Home />
            <div>
            <ChatBot
  steps={[
    {
      id: 'hello-world',
      message: 'Hello World!',
      end: true,
    },
  ]}
/>  </div>,
          </Route>
          <Route path="/about">
            <About />
          </Route>
          <Route path="/Dashboard">
            <Dashboard />
          </Route>
        </Switch>
      </div>
    </BrowserRouter>
  );
}

export default App;
