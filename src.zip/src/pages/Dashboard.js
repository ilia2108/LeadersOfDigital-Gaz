import React from "react";
import { useParams } from "react-router-dom";
import withAuth from "../components/withAuth";
import 'react-chatbox-component/dist/style.css';
import {
  CCard,
  CCardBody,
  CCardHeader,
  CListGroup,
  CBadge,
  CCol,
  CDataTable,
  CRow,
  CListGroupItem
} from '@coreui/react'
import usersData from '../data_template/UserData.js'


const Dashboard = () => {
  const { name } = useParams();
  const getBadge = status => {
    switch (status) {
      case 'Active': return 'success'
      case 'Inactive': return 'secondary'
      case 'Pending': return 'warning'
      case 'Banned': return 'danger'
      default: return 'primary'
    }
  }
  const fields = ['name','registered', 'role', 'status']

  return (<>
     <div>
       <h1 className="title is-1">Dashboard</h1>
       <article className="message is-dark" style={{ marginTop: 40 }}>
         <div className="message-header">
           <p>{name}</p>
         </div>
         <div className='container'>
   <div className='chat-header'>
     <h5>React Chat Box Example</h5>
   </div>
 </div>
     <div className="message-body">
       Lorem ipsum dolor sit amet, consectetur adipiscing elit.{" "}
       <strong>Pellentesque risus mi</strong>, tempus quis placerat ut, porta
       nec nulla. Vestibulum rhoncus ac ex sit amet fringilla. Nullam gravida
       purus diam, et dictum <a>felis venenatis</a> efficitur. Aenean ac{" "}
       <em>eleifend lacus</em>, in mollis lectus. Donec sodales, arcu et
       sollicitudin porttitor, tortor urna tempor ligula, id porttitor mi
       magna a neque. Donec dui urna, vehicula et sem eget, facilisis sodales
       sem.
     </div>
   </article>
 </div>



          <CCard style={{ marginTop: 40 }}>
            <CCardHeader>
              Condensed Table
            </CCardHeader>
            <CCardBody>
            <CDataTable 
              items={usersData}
              fields={fields}
              size="sm"
              itemsPerPage={5}
              pagination
              scopedSlots = {{
                'status':
                  (item)=>(
                    <td>
                      <CBadge color={getBadge(item.status)}>
                        {item.status}
                      </CBadge>
                    </td>
                  )

              }}
            />
            </CCardBody>
          </CCard>
      

    <CCard style={{ marginTop: 40 }}> 
    <CCardHeader>
      Today tasks
      <small>  template</small>
    </CCardHeader>
    <CCardBody>

      <CListGroup>
        <CListGroupItem action active>
          <h5 className="d-flex w-100 justify-content-between">
            List group item heading
            <small>3 days ago</small>
          </h5>
          <div className="mb-1">
            Donec id elit non mi porta gravida at eget metus. Maecenas sed diam eget risus varius blandit.
            <small>Donec id elit non mi porta.</small>
          </div>
        </CListGroupItem>
        <CListGroupItem action>
          <h5>List group item heading</h5>
          <div>
            Donec id elit non mi porta gravida at eget metus. Maecenas sed diam eget risus varius blandit.
          </div>
          <small>Small.</small>
        </CListGroupItem>
        <CListGroupItem action>
          <h5>List group item heading</h5>
          <div>
            Donec id elit non mi porta gravida at eget metus. Maecenas sed diam eget risus varius blandit.
          </div>
          <small>Small.</small>
        </CListGroupItem>
      </CListGroup>

    </CCardBody>
  </CCard>
  </>
  );
};

export default withAuth(Dashboard);
